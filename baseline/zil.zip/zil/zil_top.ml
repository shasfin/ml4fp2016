(* Start utop. It never returns. *)
let () = UTop_main.main ()
